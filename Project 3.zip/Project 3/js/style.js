      /* jssor slider bullet navigator skin 01 css */↩
	       /*↩
	       .jssorb01 div           (normal)↩
	       .jssorb01 div:hover     (normal mouseover)↩
	       .jssorb01 .av           (active)↩
	       .jssorb01 .av:hover     (active mouseover)↩
	       .jssorb01 .dn           (mousedown)↩
	       */↩
	       .jssorb01 {↩
	           position: absolute;↩
	       }↩
	       .jssorb01 div, .jssorb01 div:hover, .jssorb01 .av {↩
	           position: absolute;↩
	           /* size of bullet elment */↩
	           width: 12px;↩
	           height: 12px;↩
	           filter: alpha(opacity=70);↩
	           opacity: .7;↩
	           overflow: hidden;↩
	           cursor: pointer;↩
	           border: #000 1px solid;↩
	       }↩
	       .jssorb01 div { background-color: gray; }↩
	       .jssorb01 div:hover, .jssorb01 .av:hover { background-color: #d3d3d3; }↩
	       .jssorb01 .av { background-color: #fff; }↩
	       .jssorb01 .dn, .jssorb01 .dn:hover { background-color: #555555; }↩
↩
	       /* jssor slider arrow navigator skin 02 css */↩
	       /*↩
	       .jssora02l                  (normal)↩
	       .jssora02r                  (normal)↩
	       .jssora02l:hover            (normal mouseover)↩
	       .jssora02r:hover            (normal mouseover)↩
	       .jssora02l.jssora02ldn      (mousedown)↩
	       .jssora02r.jssora02rdn      (mousedown)↩
	       .jssora02l.jssora02lds      (disabled)↩
	       .jssora02r.jssora02rds      (disabled)↩
	       */↩
	       .jssora02l, .jssora02r {↩
	           display: block;↩
	           position: absolute;↩
	           /* size of arrow element */↩
	           width: 55px;↩
	           height: 55px;↩
	           cursor: pointer;↩
	           background: url('img/a02.png') no-repeat;↩
	           overflow: hidden;↩
	       }↩
	       .jssora02l { background-position: -3px -33px; }↩
	       .jssora02r { background-position: -63px -33px; }↩
	       .jssora02l:hover { background-position: -123px -33px; }↩
	       .jssora02r:hover { background-position: -183px -33px; }↩
	       .jssora02l.jssora02ldn { background-position: -3px -33px; }↩
	       .jssora02r.jssora02rdn { background-position: -63px -33px; }↩
	       .jssora02l.jssora02lds { background-position: -3px -33px; opacity: .3; pointer-events: none; }↩
	       .jssora02r.jssora02rds { background-position: -63px -33px; opacity: .3; pointer-events: none; }